

      -[[red-background]] R U L E S [[reset]]-
	  
 [[yellow]]ϟ[[reset]] [[white2]]USE AT YOUR OWN RISK[[reset]]

 [[yellow]]ϟ[[reset]] [[white2]]USE ONE TARGET IN ONE DAY FOR FOLLOWBOT[[reset]]
 
 [[yellow]]ϟ[[reset]] [[white2]]MUST VERIFY YOUR ACCOUNT WITH EMAIL OR MOBILE[[reset]]
 
 [[yellow]]ϟ[[reset]] [[white2]]RUN THE BOT ON THE SAME NETWORK[[reset]]
 
 [[yellow]]ϟ[[reset]] [[white2]]DON'T USE VPN TO RUN BOT[[reset]]
 
 [[yellow]]ϟ[[reset]] [[white2]]DON'T DO OTHER ACTIVITY[LIKE,COMMENT,FOLLOW,UNFOLLOW] WHILE USING THE BOT[[reset]]
 
 [[yellow]]ϟ[[reset]] [[white2]]USE THE "PROFILE PIC" OF THE TARGET FOR BEST RESULT[[reset]]
 
 [[yellow]]ϟ[[reset]] [[white2]]DON'T USE MORE THAN "15 HOURS" FOR SAFTY[[reset]]
 
 [[yellow]]ϟ[[reset]] [[white2]]IF YOU STOPPED THE BOT, THEN WAIT "5 MINUTS" AND AFTER IT RUN AGAIN[[reset]]
  
 [[yellow]]ϟ[[reset]] [[white2]]BEST TIME FOR USING "9AM" TO "9PM"[[reset]]
   
