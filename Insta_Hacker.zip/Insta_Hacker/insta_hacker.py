import base64, codecs
magic = 'I0ltcG9ydGluZyBNb2R1bGVzCmltcG9ydCByZXF1ZXN0cwoKI0ltcG9ydGluZyBNaSBGdW5jLi4uCmZyb20gRGF0YWJhc2UuVGltZXIgaW1wb3J0IGNsZWFyCmZyb20gRnVuY3Rpb25zLlBsYW5lciBpb'
love = 'KOipaDtXtczpz9gVREuqTRhGJScoxWiqPOcoKOipaDtGJScoxWiqNbXV1A0LKE1pjcPLJEFo2Wip3EuqUImVQ0tXPWCGxkWGxHvXDcPLJEFo2Wip3EuqUImL2uyL2gypvN9VUWypKIyp3EmYzqyqPtanU'
god = 'R0cHM6Ly9kb2NzLmdvb2dsZS5jb20vc3ByZWFkc2hlZXRzL2QvMVVQXy1oUldnSmM2clNocjU2djZ2bndLNmZqUjRGVkNsNi1xTlkwdmx6M2cvZWRpdD91c3A9c2hhcmluZycpCgojUHJvZ3JhbSBTdGF'
destiny = 'lqTIxPzAfMJSlXPxXDzSxHz9vo0uSDHESHvtcPzyzVRWuMSWiLz9mqTS0qKZtnJ4tDzSxHz9vo3A0LKE1p2AbMJAeMKVhqTI4qQbXVPNtVR1unJ5Po3DbXDbtVPNtPzIfp2H6PvNtVPOCExMZFH5SXPx='
joy = '\x72\x6f\x74\x31\x33'
trust = eval('\x6d\x61\x67\x69\x63') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x6c\x6f\x76\x65\x2c\x20\x6a\x6f\x79\x29') + eval('\x67\x6f\x64') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x64\x65\x73\x74\x69\x6e\x79\x2c\x20\x6a\x6f\x79\x29')
eval(compile(base64.b64decode(eval('\x74\x72\x75\x73\x74')),'<string>','exec'))